
using IoTHubTrigger = Microsoft.Azure.WebJobs.EventHubTriggerAttribute;

using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Azure.EventHubs;
using System.Text;
using System.Net.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;

namespace com.trigger.clinical.data
{

    public class PatientData
    {
        public string Id { get; set; }
        public string BloodPressure { get; set; }
        public string SugarLevel { get; set; }
        public string Gender { get; set; }
        public string Age { get; set; }
    }
    public class IoTHubEventClinical
    {
        private static HttpClient client = new HttpClient();


        [FunctionName("myIoTHubTrigger")]
        public static void Run([IoTHubTrigger("messages/events", Connection = "AzureEventHubConnectionString")] EventData message,
                [CosmosDB(databaseName: "iotData",
                                 collectionName: "Clinicaldata",
                                 ConnectionStringSetting = "cosmosDBConnectionString")] out PatientData output,
                               ILogger log)
        {
            log.LogInformation($"C# IoT Hub trigger function processed a message: {Encoding.UTF8.GetString(message.Body.Array)}");

            var jsonBody = Encoding.UTF8.GetString(message.Body);
            dynamic data = JsonConvert.DeserializeObject(jsonBody);
            string age = data.age;
            string gender = data.gender;
            string sugarLevel = data.sugarLevel;
            string bloodPressure = data.bloodPressure;

            output = new PatientData
            {
                BloodPressure = bloodPressure,
                SugarLevel = sugarLevel,
                Gender = gender,
                Age = age
            };

        }
        [FunctionName("GetClinicalAllData")]
        public static IActionResult GetClinicalAllData(
[HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "allsensor")] HttpRequest req,
[CosmosDB(databaseName: "iotData",
                  collectionName: "Clinicaldata",
                  ConnectionStringSetting = "cosmosDBConnectionString",
                      SqlQuery = "SELECT * FROM c")] IEnumerable< PatientData> PatientData,
 ILogger log)

        {
            return new OkObjectResult(PatientData);
        }
        [FunctionName("GetClinicaldataMaleGender")]
        public static IActionResult GetClinicaldataBaseMaleGender(
[HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "clinical/Male")] HttpRequest req,
[CosmosDB(databaseName: "iotData",
                  collectionName: "Clinicaldata",
                  ConnectionStringSetting = "cosmosDBConnectionString",
                      SqlQuery = "SELECT * FROM c WHERE c.Gender = 'Male'")] IEnumerable< PatientData> maledata,
ILogger log)

        {
            return new OkObjectResult(maledata);
        }

        [FunctionName("GetClinicaldataFemaleGender")]
        public static IActionResult GetClinicaldataFemaleGender(
[HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "clinical/Female")] HttpRequest req,
[CosmosDB(databaseName: "iotData",
                  collectionName: "Clinicaldata",
                  ConnectionStringSetting = "cosmosDBConnectionString",
                      SqlQuery = "SELECT * FROM c WHERE c.Gender = 'Female'")] IEnumerable< PatientData> femaleData,
ILogger log)

        {
            return new OkObjectResult(femaleData);
        }

        [FunctionName("getHighgBp")]
        public static IActionResult getHighgBp(
[HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "high/bp")] HttpRequest req,
[CosmosDB(databaseName: "iotData",
                  collectionName: "Clinicaldata",
                  ConnectionStringSetting = "cosmosDBConnectionString",
                      SqlQuery = "SELECT * FROM c WHERE c.Gender = 'Female'")] IEnumerable< PatientData> femaleData,
ILogger log)

        {
            return new OkObjectResult(femaleData);
        }

        [FunctionName("getsugarLevel")]
        public static IActionResult getsugarLevel(
[HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "sugarLevel")] HttpRequest req,
[CosmosDB(databaseName: "iotData",
                  collectionName: "Clinicaldata",
                  ConnectionStringSetting = "cosmosDBConnectionString",
                      SqlQuery = "SELECT * FROM c  WHERE  (c.SugarLevel BETWEEN '1' AND '120')")] IEnumerable< PatientData> sugarLevelData,
ILogger log)

        {
            return new OkObjectResult(sugarLevelData);
        }

        [FunctionName("Verifier")]
        public static IActionResult Verifier(
    [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "loaderio-049218ebf4779518eaf209cfc09fc11b")] HttpRequest req,
    ILogger log
)
        {
            return new OkObjectResult("loaderio-049218ebf4779518eaf209cfc09fc11b");
        }




    }
}

